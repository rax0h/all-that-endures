# Source compatibility, obsolete benchmark config and quick gates

Read-only investigation. No repository edits, index or branch mutations, CI
launches or new green claims. This supplements the separate B2 engine report.

## The remaining harness failures

Preserved workspace-capable run `harness-workspace-red.log/xml` inside
`docs/performance/stage-0-6-current/forensic-repair/baseline-and-preservation-tests.zip`
reports 12 failed/7 passed when rerunning the original 19 failed selectors. The
remaining failures comprise two B2 engine cases, seven compatibility cases, and
these three benchmark cases:

| Test | Actual cause |
|---|---|
| `test_exact_workflow_measure_and_verify_launchers_on_small_fixture` | Inherits obsolete production runtime pin, exits at `execution SHA/runtime differs from reviewed source` before useful measurement |
| `test_exact_workflow_sample_launcher_on_small_authenticated_fixture` | Same inherited production runtime pin, same pre-measurement failure |
| `test_single_stage06_mature_workflow_and_bounded_diagnostic_lane` | Assumes every Stage0.6 YAML filename must be exactly the two October workflows; rejects added preservation, inventory and resumable workflows |

No additional run was needed to establish these causes: the preserved XML has
the exact subprocess command, failure and traceback. The seven /tmp-capacity
failures are a separate environment issue already resolved by the parent.

## agency.py canonical compatibility

Only one of the compatibility manifest's fenced files differs:

| File | Existing current pin | Actual current bytes |
|---|---|---|
| `simulation/ate_sim/agency.py` | `38d0538421cc714fa51f602995cb7eeaa230b2d192c9a2d7fd68faeb0eacf01d` | `2bd6693fe4640a80ba3bc07ad33d71fd1ed46fe65b413db9ce33828bc3bfc1ad` |

The complete diff from both accepted source commit
`2cbf3510ef1f0ad8ddd712a1c4174ccfa518291a` and declared current engine tree
`94267bb00a219702a4bd1700a2fc0600a5c5aa56` is f00e7e4's local operand-lifetime
change in `_practice_path`: materialize `abilities=tuple(path.abilities)` before
PracticeBatch, then use that tuple for ceiling and candidate enumeration.

`compatibility-analysis.json` records an AST comparison: `_practice_path` is the
only changed top-level definition; every class declaration is identical. No
MotiveState, ActionRecord or AgencyState fields, action emission/retention,
canonical serializer, persistent schema or decoder bytes changed in this diff.
Digesting/restoring the unchanged source does not run `_practice_path`. Thus this
change does not alter the accepted source's canonical emission. It does change
lazy object residency/read timing during a future action; that is a separate
runtime behavior subject to normal engine validation.

The retained design and existing
`simulation/tests/test_stage_0_6_action_ability_lifetime.py` cover RNG, events,
digest, save/reopen and canonical aliases across empty/partial/full/ceiling,
milestone and body-transition actions. This investigation did not rerun them or
claim mature continuation from source inspection.

### Minimal honest compatibility repair

- Record the reviewed agency byte change and this source-emission rationale.
  Preserve its historical SHA, historical runtime SHA/tree, accepted source
  digest, actual accepted member bytes/SHA and every source/proof producer pin.
- Update the manifest's current agency SHA to the exact reviewed current bytes
  and current_runtime_tree to the actual final committed repaired engine tree.
  The latter is a source-compatibility declaration, not a CI green assertion.
  Do not retain the old94267 current-runtime label with new agency bytes.
- Replace hardcoded94267 happy-path test arguments with the manifest's declared
  current pair; separately assert that real repository compatibility targets the
  actual committed candidate engine tree. Keep historical pair pins exact and
  negative pair mutations. Add agency.py itself to the definition-byte mutation
  loop, retaining all current codec/schema/model mutations.
- Leave production launcher green qualification fail-closed until the actual
  changed engine has a real green proof/full run. Do not change accepted source
  digest or expected year1002 digest to make a mismatch disappear.

`check_compatibility()` itself correctly rejects unknown bytes today; it should
not be loosened to ignore agency.py, accept arbitrary model drift, use only AST
structure, or automatically bless whatever bytes happen to be present.

## Obsolete benchmark launch pins

`simulation/stage_0_6_benchmark_launch.json` declares runtime
`575d90fc4cce733e002aaf604ca5d131b265d756`, green commit b303092 and October28
launch identity. The actual engine at investigation start is fd20cf17 and the
parent is repairing it further. Moreover, b303092's actual engine is63d5ac48,
not575d90fc: this config is a historical launch specification, not current engine
qualification.

`check_source()` verifies execution SHA, configured runtime, clean source,
imported runtime, exact file fingerprints and green ancestry. It does **not**
verify that the green ancestor's engine tree equals configured runtime. Updating
only runtime_tree while keeping this green ancestor would therefore allow an
untested descendant engine through this particular check.

### Minimal honest benchmark repair

The two shell tests should construct an explicit **temporary smoke launch** for
the committed checkout they are testing: exact test HEAD/runtime/fingerprints,
tiny fixture authority and budgets. A synthetic `green_commit=HEAD` within this
temporary test fixture tests source-fence/shell behavior; it must never be written
to production configuration or reported as actual CI qualification. Existing
negative source-fence tests remain mandatory. This separates executable shell
regression coverage from a historical production launch's deliberately fixed
pins and avoids the circular need for new CI before testing its own harness.

Retain historical config/provenance explicitly as historical. If the legacy
format6 benchmark remains supported for a new real run, prepare a new reviewed
launch ID with exact candidate runtime, fingerprints and a genuine green source
of that engine after that green exists. Preserve original source/control pins.
Strengthen the real launch fence to require
`green_commit:simulation/ate_sim == configured runtime_tree`, in addition to its
existing ancestry/import/dirty/hash checks, and authenticate CI evidence rather
than counting a synthetic shell test as qualification.

The selected resumable path is separately pinned in
`simulation/stage_0_6_genesis_resume.py:27`: GREEN_RUN42823293423,
GREEN_SHA9e6f022, runtime94267, exact full/proof job IDs and artifact IDs/digests.
Those pins are internally consistent but obsolete for the changed engine. Update
the whole green tuple only from an authenticated new successful proof/full run,
including observed software/source receipts and exact artifact digests. An old
green and a new runtime must not be combined. Keep the historical source/control
lineage independent from this execution qualification.

## Supported lane contract instead of global workflow count

Assert behavior of named lanes and their authority/cost boundaries. A global
Stage0.6 filename count is not an invariant. Suggested explicit mapping:

| Workflow | Role and assertions |
|---|---|
| `stage-0-6-resumable-proof-genesis.yml` | Selected staged current proof path: full harness before gate, exact green and compatible hosted smoke before mature, sealed closed-stage transport, stage budgets, dependency success and exact final continuation |
| `stage-0-6-audit-attribution.yml` | Bounded diagnostic: 15min job, 10min probe, boundary regressions, no mature fixture transport/full measurement or history generation |
| `stage-0-6-fixture-preservation.yml` | Private authenticated transport only: actual smoke before large copy, draft-only, immutable chunk IDs/digests and full restore; no World construction, SQL expansion or simulation |
| `stage-0-6-proof-mature-preflight.yml` | Explicit historical inventory lane: no World restore/step, reviewed source/runtime/config and bounded inventory; no performance acceptance |
| `stage-0-6-current-mature-performance.yml` | Explicit historical default-format measurement/retain lane until requalified: full measurement manual-only, retain-and-sample never saves or claims acceptance, separate timers/fresh verification and exact source immutability |

Keep the old test's useful manual-measure, retained-sample, cancel-in-progress,
timeout, diagnostic-isolation and source-trigger assertions. Add role-specific
assertions for the new workflows rather than extending a filename equality list.
Mark historical roles in workflow names/comments and documentation so users do
not mistake the filename's word `current` for current-engine qualification.
Reject an unexpected *new expensive launch behavior*, not every new workflow.

## Required full .github/tests quick gate placement

Run `python -m pytest -q .github/tests` once before expensive work for the same
workflow/candidate. Use the pinned interpreter via PATH for subprocesses, real
workspace disposable disk, source/runtime receipts, bounded command/job budgets,
pipefail and always-preserved log/XML. The current local baseline is minutes,
unlike multi-hour engine/construction work. A 10min command within a 15min quick
job reserves cleanup/publication; adjust only from actual observed bounded cost.

| Workflow | Concrete placement |
|---|---|
| `stage-0-5-proof-map-validation.yml` | Add one harness job; require it with `needs` on both90min proof-map and195min full-suite. The mature-genesis dependency chain then inherits it. Cheap request detection may run in parallel. Include .github test/helper and relevant harness paths in triggers. |
| `stage-0-6-resumable-proof-genesis.yml` | Replace selected-only test list in existing gate before `decide`, since `decide` can authenticate/transport source. Every expensive stage already requires gate success. Do not rerun full harness for every resumed stage. |
| `stage-0-6-current-mature-performance.yml` | Replace selected-only gate in the selected measure/retain job before disk cleanup and `prepare` download. Only one mode runs; alternatively one shared required harness job. |
| `stage-0-6-proof-mature-preflight.yml` | Replace selected-only gate before large input download/inventory. |
| `stage-0-6-fixture-preservation.yml` | To apply the requirement to large transfers too, make preserve additionally depend on one full harness gate, alongside actual transport smoke; do not repeat it per chunk. Existing smoke currently runs only preservation tests. |

For proof-map's long jobs, adding tests as an unrelated parallel job is
insufficient: `needs` must actually prevent their launch on harness failure.
Do not add a full simulation suite to the quick harness gate, repeat a compatible
successful engine gate for each minor finding, or count workflow success while
the required gate was skipped/continued-on-error.

## Key source references

- `simulation/stage_0_6_genesis_source_control.py:10`: exact compatibility fence.
- `simulation/stage_0_6_genesis_control_compatibility.json:42`: agency SHA pair.
- `simulation/ate_sim/agency.py:24`: sole changed function.
- `.github/tests/test_stage_0_6_genesis_source_control.py:21`: copied definitions
  and declared pair; hardcoded94267 also appears at51/52/59/65.
- `.github/tests/test_stage_0_6_benchmark.py:74` and `:216`: tiny shell tests
  inherit obsolete production execution pins.
- `.github/tests/test_stage_0_6_benchmark.py:143`: obsolete global filename test.
- `simulation/stage_0_6_mature_benchmark.py:14`: source/ancestry/fingerprint fence.
- `simulation/stage_0_6_genesis_resume.py:27`: coordinated real-green tuple;
  `:94` is current-runtime critical-dependency fence.
- `.github/workflows/stage-0-5-proof-map-validation.yml:68` and `:176`: expensive
  jobs currently have no harness prerequisite.
- `.github/workflows/stage-0-6-resumable-proof-genesis.yml:58`: selected-only
  harness gate before source decision.
- `.github/workflows/stage-0-6-current-mature-performance.yml:37` and `:127`:
  selected-only gates before transport.
- `.github/workflows/stage-0-6-proof-mature-preflight.yml:29`: selected-only gate.
- `.github/workflows/stage-0-6-fixture-preservation.yml:35` and `:54`: targeted
  smoke tests and large preserve dependency.
