# Audited native save/recovery investigation

Read-only checkout investigation for forensic repair B2/F3. No repository file,
index or branch was changed by this investigator. Only live Python objects were
patched by probes outside the checkout. This is root-cause/design evidence, not
the package's final independent review or a production repair.

## Finding

The two reported audit-epoch failures are an engine regression at the composition
of postcommit audit reuse and the later native-source fence. They are not an
unqualified-runtime failure or merely outdated test expectations.

Current exact tests fail in 8.06 seconds on the fully matching qualified runtime.
`runtime.json` records equality of Python executable SHA, Python/compiler, SQLite
version/source ID/compile options, extension path/SHA and loaded SQLite library
path/SHA against the qualification receipt. Child PATH uses the same runtime.
Engine tree is `fd20cf1784a331de07f4979db71dda0f3d301771`. Initial reviewed HEAD
was `130f6398d94aba522840c9b7f7cb9a4073f0c6d1`; the parent subsequently advanced
non-engine work to `1783733783c0f0229d386347ba412d1d9ac27ad9` during this
investigation. Engine tree remained unchanged.

## Actual first failure

1. A structural save commits generation 1. Authority `commit()` advances `pair`
   and `read_pin` to the successor and obtains a full postcommit audit receipt.
2. The test's separate SQLite writer commits after that audit returns, changing
   data_version and (for benign DDL) main.schema_version.
3. Before `execute()` reaches its intended stale-receipt fallback, the callback
   enters `_publish_committed_hybrid()` and the first participant's checked read.
4. Native-source `_epoch()` compares the current SQLite epoch with
   `authority.epoch`, still the admitted parent's epoch. It correctly refuses
   the changed source, raising `StoreConflictError: native source snapshot epoch
   differs from accepted authority`.
5. `_publish_committed_hybrid()` classifies *every* StoreConflictError as stale.
   This is wrong for an epoch change that has not established a competing head:
   the exact original committed attempt still exists and needs recovery.
6. The corrupt test restores only the committed checksum, but public recovery
   immediately fails with `StoreConflictError: lazy World session is stale`.
7. `finally: session.close()` then attempts a checked dependency snapshot while
   authority is uncertain and masks the useful error with `native source
   publication requires exact recovery`.

The source fence is doing necessary work. Removing it, skipping it whenever busy,
or wrapping the whole acknowledgement in publisher capability would be unsafe.

## Contract and provenance

`docs/performance/stage-0-6-current/audit-reuse/closure.md:36` explicitly promises
that an actual benign separate-connection post-audit schema change fresh-audits,
and actual checksum corruption remains recoverable after restoring only the
injected new checksum. The failure test implements exactly that promise.

`docs/superpowers/specs/2026-11-05-ate-native-source-reads.md:17` requires exact
accepted generation and epoch at native reads and explicitly states that busy
acknowledgement is not a blanket exemption. Neither contract revokes the other.

Commit `747880e60bb50a06d443057527f642d8a0084021` introduced the native-source
adapter and these epoch checks after audit reuse. The pre-existing external-write
test was retained. This identifies the incompatible composition; I did not run a
historical checkout/bisect or claim to have proven the earliest bad commit by
execution.

## Recommended minimal repair

Use an operation-local **audited read receipt** for the postcommit acknowledgement
phase, and retain the final public authority transition in `execute()`.

1. Add a private local receipt containing the successful audit epoch, exact
   successor `pair` identity and `read_pin`. Initialize/clear it at execute entry
   and in execute finally, including exceptions and recovery.
2. At structural `commit()`'s existing postcommit audit, compare the returned
   receipt with the actual current epoch before returning to native publication.
   If changed, run the existing full accepted-root `_audit()` again. Install only
   that audit's returned receipt into the local read context. Update
   `_postcommit_verified_epoch` with this same successful receipt so matching
   saves retain their one-authority-audit optimization and changed receipts retain
   two. A further writer race is still refused; do not spin without a bound.
3. `resolve()` must retain its existing full audit before any native publication
   read and install its returned epoch into this local read context. Keep its
   independent final execute audit behavior; do not grant authority from a
   SQLite epoch observation or the recovery receipt's existence alone.
4. Native-source `_epoch()` may select this expected audited epoch only while
   the exact authority-owned write guard owns the operation, a pending original
   attempt exists, and receipt pair/read_pin still match. All ordinary fetches,
   pre/post-BEGIN checks, positive/absence/root checks, size limits, closed codec,
   schema and callback restrictions continue to run.
5. A new source epoch mismatch during an owned operation with its pending
   original attempt must be *recoverable uncertainty*, not evidence of a foreign
   successor. Raise a distinct StoreError (or a dedicated recoverable error) so
   `_publish_committed_hybrid` does not mark it stale. Keep the original conflict
   behavior outside that narrowly owned postcommit context. Exact token/parent
   resolution must determine whether a foreign head really won.

Do not eagerly set `authority.epoch` to the successor's audit receipt before
`execute()` completes. `execute()` uses that field to decide whether it needs a
final audit; eager assignment can skip independent recovery checks. Do not derive
the receipt from `authority._epoch()` alone.

No SQLite transaction needs to remain open across acknowledgement for this
repair. The existing before/after-BEGIN source fencing refuses a writer that
races the local receipt. That late refusal must remain publicly recoverable.

## Probe evidence

All probes use PYTHONDONTWRITEBYTECODE=1, qualified PATH, PYTHONPATH=.:simulation,
pytest cache disabled, external basetemp and an enclosing 115-second timeout.
There was no full-suite or generated-millennium execution.

| Probe | Result | Meaning |
|---|---|---|
| `exact-repro.log` | 2 failed, 8.06s | Exact engine failures reproduced, including first exception chains |
| `handoff-probe.log` | 7 passed, 22.45s | Initial eager epoch hypothesis explains the regression, but is not the recommended production design |
| `late-race-results.json` | Original classification becomes stale; narrow recoverable classification restores exact recovery | Refreshing before ack alone does not solve a writer racing after the refresh |
| `scoped-handoff-probe.log` | 15 passed, 46.07s | Recommended scoped-receipt prototype preserves original final authority handling |
| `scoped-late-race-results.json` | Benign and corrupt late races refused; recovery and reopen succeed only after valid state restored | The repair does not turn a post-audit receipt into a write-safety bypass |

The 15 selected cases comprise both exact external-write variants, in-place codec
hook refusal, leaked acknowledgement transaction refusal, three original-parent
fault/recovery phases, unrelated-body recovery authentication, local/external
untracked-SQL refusal, matching/stale receipt audit counts, foreign lease refusal,
and trace-callback write refusal in both publisher and entry-epoch phases.

The late-race probes inject the separate connection's write immediately before
`_publish_committed_hybrid` enters its participants, after the new local read
receipt is prepared. Both leave physical generation 1 and retain the original
pending plan/authority. With the narrow error classification, state is
`recovery-required`, a still-corrupt body fails the recovery audit with
`ordinary record checksum mismatch`, and restoring only its checksum permits
resolve=1, no-op save=1 and reopening memory `[1, 2, 3]` from the accepted child.

## Regression coverage for production repair

- Keep the exact two reported tests and their audit counts unchanged.
- Add a separate-connection write *after* scoped handoff and before participant
  snapshot: fail safely, remain recovery-required with original token/parent,
  recover benign drift, reject corruption until repaired, reopen exact child.
- Verify local receipt is cleared after success/failure/recovery, cannot be used
  with another pair/read_pin/guard, and never updates public authority early.
- Retain matching/stale receipt, closed-codec/open-transaction, pre-save external
  SQL, checksum-consistent accepted-root rejection, callback and foreign lease
  tests. Include genuine foreign successor conflict to keep stale semantics.
- Keep the audited opener and complete accepted-root audit. These small probes
  do not establish mature performance or package-wide correctness.

## Source references in the checkout

- `simulation/ate_sim/persistence_proof_world_session.py:114`: final execute
  boundary, fallback audits and final public epoch transition.
- `simulation/ate_sim/persistence_proof_world_session.py:147`: commit, pending
  original parent/token, successor pair/read_pin and postcommit receipt.
- `simulation/ate_sim/persistence_proof_world_session.py:176`: recovery audit.
- `simulation/ate_sim/persistence_proof_native_sources.py:17`: callback and exact
  publisher-capability checks.
- `simulation/ate_sim/persistence_proof_native_sources.py:36`: pre-snapshot
  uncertainty/generation/epoch checks.
- `simulation/ate_sim/persistence_proof_native_sources.py:48`: failing epoch
  comparison; `:57` is the read-view-established recheck.
- `simulation/ate_sim/persistence_lazy.py:16586`: participant validation and
  blanket stale classification.
- `simulation/ate_sim/persistence_lazy.py:16805`: normal postcommit exceptions
  retain recovery-required state.
- `simulation/ate_sim/persistence_lazy.py:16817`: stale short-circuit blocks
  exact recovery.
- `simulation/ate_sim/persistence_history_dependencies.py:233` and
  `simulation/ate_sim/persistence_lazy.py:17999`: cleanup masks the first error.
- `.github/tests/test_stage_0_6_audit_epoch.py:11`: actual external-write
  regression and recovery expectation.

The parent separately identified the small benchmark's disposable-disk reserve
failure and source/runtime launch fences. No benchmark causality is inferred
from this engine investigation.
