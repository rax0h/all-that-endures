import copy, hashlib, json, sys, zipfile
from pathlib import Path
import pytest
ROOT=Path('/workspace/scratch/c88cf88fdaa2/ate-rebase-repair')
sys.path.insert(0,str(ROOT/'.github/tests'))
import test_stage_0_6_after_digest_admission as fixtures
from simulation import stage_0_6_after_digest_admission as a
from simulation import stage_0_6_genesis_resume as m
from simulation import stage_0_6_genesis_checkpoint as c
from simulation import stage_0_6_genesis_source_control as controls

@pytest.fixture
def admitted(monkeypatch):
    parent=fixtures.old_after('mature')
    artifacts,runs=fixtures.recorded_service(monkeypatch)
    runtime,blobs=m.fence(ROOT)
    ctx=copy.deepcopy(parent['context']);ctx.update(runtime_tree=runtime,critical_blobs=blobs)
    monkeypatch.setattr(m,'runtime_description',lambda:(ctx['execution_runtime'],{}))
    stamp=a.attest(ROOT,parent,ctx)
    return fixtures.proved(parent,ctx,stamp),artifacts,runs

def test_real_current_fence_covers_new_authorities(admitted):
    row,_,_=admitted
    for path in (a.CONTRACT,'simulation/stage_0_6_after_digest_admission.py','simulation/stage_0_6_catalog_admission.json'):
        assert path in row['context']['critical_blobs']
    assert a.validate_chain(ROOT,row)['context']['mode']=='mature'
    controls.validate_control_chain(ROOT,row,current_runtime_tree=m.RUNTIME)

@pytest.mark.parametrize('case',['helper','engine','runtime','missing-cut'])
def test_current_context_cannot_be_rebound(admitted,case):
    row,_,_=admitted
    if case=='missing-cut':del row['metrics']['proofs_admission']
    else:
        if case=='helper':row['context']['critical_blobs']['simulation/stage_0_6_after_digest_admission.py']='a'*40
        elif case=='engine':row['context']['runtime_tree']='a'*40
        else:row['context']['execution_runtime']['signature']='a'*64
        row['metrics']['proofs_admission']=fixtures.marker(row['parent']['receipt'],row['context'])
    with pytest.raises(ValueError):a.validate_chain(ROOT,row)

@pytest.mark.parametrize('which',['after-meta','after-data','catalog-meta','catalog-data'])
@pytest.mark.parametrize('damage',['duplicate-producer','failed-publication','archive-changed','expiry'])
def test_each_historical_publication_has_independent_live_authority(admitted,which,damage):
    row,artifacts,runs=admitted
    new=a.contract(ROOT)['after_digests']['mature']
    old=json.loads((ROOT/'simulation/stage_0_6_catalog_admission.json').read_text())['catalogs']['mature']
    ref=dict(zip(['after-meta','after-data','catalog-meta','catalog-data'],[new['metadata'],new['data_ref'],old['metadata'],old['data_ref']]))[which]
    if damage=='archive-changed':artifacts[ref['artifact_id']]['digest']='sha256:'+'0'*64
    elif damage=='expiry':artifacts[ref['artifact_id']]['expires_at']='2026-01-01T00:00:00Z'
    else:
        jobs=runs[ref['run_id']]['jobs']['jobs']
        eligible=[job for job in jobs if job['name']==ref['job']]
        assert len(eligible)==1
        if damage=='duplicate-producer':jobs.append(copy.deepcopy(eligible[0]))
        else:
            steps=eligible[0]['steps'];step=next(s for s in steps if s['name']=='Publish sealed checkpoint metadata');step['conclusion']='failure'
    with pytest.raises(ValueError):a.validate_chain(ROOT,row)

def test_index_and_retained_archives_match():
    root=ROOT/'docs/performance/stage-0-6-current/after-digest-admission'
    for name,expected in json.loads((root/'evidence-index.json').read_text()).items():
        data=(root/name).read_bytes()
        assert len(data)==expected['bytes'] and hashlib.sha256(data).hexdigest()==expected['sha256']
    for name in ('inputs.zip','local-evidence.zip','qualified/14288380650.zip','qualified/14292956213.zip','qualified/14297230116.zip'):
        with zipfile.ZipFile(root/name) as z:assert z.testzip() is None
