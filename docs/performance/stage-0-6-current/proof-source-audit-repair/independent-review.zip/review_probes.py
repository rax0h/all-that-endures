"""Independent recorded-evidence probes; writes only beside this scratch script."""
import copy
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile

ROOT=Path('/workspace/scratch/c88cf88fdaa2/ate-rebase-repair')
BASE=ROOT/'docs/performance/stage-0-6-current/proof-source-audit-repair'
OUT=Path(__file__).parent
results={'head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=ROOT,text=True).strip(),'archives':{},'publication_probes':{}}
results['reviewed_file_sha256']={name:hashlib.sha256((ROOT/name).read_bytes()).hexdigest() for name in (
    'simulation/ate_sim/persistence_proof_world.py',
    'simulation/tests/test_stage_0_6_world_source_audit.py',
    '.github/tests/test_stage_0_6_catalog_admission.py',
    '.github/tests/test_stage_0_6_proof_failure_evidence.py',
    'docs/performance/stage-0-6-current/proof-source-audit-repair/authenticate-retained.py')}
for name,entry in json.loads((BASE/'evidence-index.json').read_text()).items():
    path=BASE/name
    assert path.stat().st_size==entry['bytes']
    assert hashlib.sha256(path.read_bytes()).hexdigest()==entry['sha256']
    with zipfile.ZipFile(path) as z:
        assert set(z.namelist())=={m['name'] for m in entry['members']}
        for member in entry['members']:
            data=z.read(member['name'])
            assert len(data)==member['bytes']
            assert hashlib.sha256(data).hexdigest()==member['sha256']
    results['archives'][name]={'sha256':entry['sha256'],'members_verified':len(entry['members'])}

for mutation in ('none','after_metadata_time','rebase_metadata_time','rebase_data_time','duplicate_after_job'):
    with tempfile.TemporaryDirectory(dir=OUT) as directory:
        evidence=Path(directory)
        with zipfile.ZipFile(BASE/'failure.zip') as z:z.extractall(evidence)
        raw=json.loads((evidence/'metadata.json').read_text())
        if mutation=='duplicate_after_job':
            raw['jobs']['jobs'].append(copy.deepcopy(next(j for j in raw['jobs']['jobs'] if j['name']=='after-digest')))
        elif mutation!='none':
            artifact_id={'after_metadata_time':14267625292,'rebase_metadata_time':14260383532,'rebase_data_time':14261110486}[mutation]
            artifact=next(a for a in raw['artifacts']['artifacts'] if a['id']==artifact_id)
            job=next(j for j in raw['jobs']['jobs'] if j['name']==('after-digest' if artifact_id==14267625292 else 'rebase'))
            artifact['created_at']=job['started_at']
        (evidence/'metadata.json').write_text(json.dumps(raw))
        run=subprocess.run([sys.executable,str(BASE/'authenticate-retained.py'),str(ROOT),str(evidence)],cwd=ROOT,text=True,capture_output=True)
        results['publication_probes'][mutation]={'returncode':run.returncode,'stdout':run.stdout,'stderr':run.stderr}

path=OUT/(sys.argv[1] if len(sys.argv)>1 else 'probes.json')
path.write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'output':str(path),'head':results['head'],'archives':results['archives'],'publication_probe_returncodes':{name:value['returncode'] for name,value in results['publication_probes'].items()}},indent=2))
